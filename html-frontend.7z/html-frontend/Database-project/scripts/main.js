// When the user scrolls the page, execute permanentMenu
window.onscroll = function () { permanentMenu(); };

// When the browser window is resized (or is less than 600px at page load), call
// menuCollapsed. Also setup the submenus for store, set up image rollovers, and 
// setup form
window.onresize = function () { menuCollapsed(); };
window.onload = function () {
  menuCollapsed();
  setUpSubMenus();
  setUpFormValidation();
};


// Initialize image array with all original images on page for restore
var originalImages = {};

// Keep track of expanded menu and sub-menus
var isExpanded = false;
var isSubMenuExpanded = false;

// Get window width
var windowWidth = window.innerWidth;

// Get desktop menu and desktop menu links
var mainNavBar = document.getElementById('desktop-menu');
var mainMenuLinks = document.getElementById('navigation-links');

// Get mobile menu and mobile menu links 
var mobileNavBar = document.getElementById('mobile-menu');
var mobileMenuLinks = document.getElementById('mobile-nav-links');

// Get menu button reference
var menuButton = document.getElementById('menu-button');

// Get desktop and mobile store links
var desktopStoreLink = document.getElementById('main-store-link');
var mobileStoreLink = document.getElementById('mobile-store-link');

// Get expandable desktop and mobile dropdown links
var desktopDropDown = document.getElementById('desktop-dropdown');
var mobileDropDown = document.getElementById('mobile-dropdown');

// Get the main content
var content = document.getElementById("main-content");

// Get form submit button on page
var submitButton = document.getElementById('submit-button');


// Add the sticky class to the navbar when you reach its scroll position
// Remove "permanent" when you leave the scroll position
// Also add extra padding to main content so it doesn't jump
// Changes made since we have two navbars now
function permanentMenu() {
  // Get the offset position of the navbar
  var sticky = null;

  if (windowWidth == null) {
    return;
  } else if (windowWidth > 600) {
    sticky = mainNavBar.offsetTop;
  } else {
    sticky = mobileNavBar.offsetTop;
  }

  if (window.pageYOffset >= sticky + 250) {
    if (mainNavBar != null) {
      mainNavBar.classList.add("permanent");
    }
    if (mobileNavBar != null) {
      mobileNavBar.classList.add("permanent");
    }
    content.classList.add("scroll-content");
  } else {
    if (mainNavBar != null) {
      mainNavBar.classList.remove("permanent");
    }
    if (mobileNavBar != null) {
      mobileNavBar.classList.remove("permanent");
    }
    content.classList.remove("scroll-content");
  }
}


// Set up and show collapsible menu
function menuCollapsed() {
  // Refresh window width
  windowWidth = window.innerWidth;

  /* Return if window width is null. If window width is greater than 600px, show the normal nav bar and hide collapsible nav button. Otherwise hide the normal nav bar and show the collapsible nav button */
  if (windowWidth == null) {
    return;
  } else if (windowWidth > 600) {
    mainNavBar.classList.remove("hidden");
    mobileNavBar.classList.add("hidden");
  } else {
    mainNavBar.classList.add("hidden");
    mobileNavBar.classList.remove("hidden");
  }

  /* Setup collapsible menu action when menu button is clicked. This is setup regardless of the state of the menu button, making sure the function will be ready when needed */
  if (menuButton != null) {
    menuButton.onclick = function () {
      if (!isExpanded) {
        mobileMenuLinks.classList.remove("hidden");
        isExpanded = true;
      } else {
        mobileMenuLinks.classList.add("hidden");
        isExpanded = false;
      }
    };
  }
}


/* Setup submenus for the store link */
function setUpSubMenus() {
  if (desktopStoreLink == null || mobileStoreLink == null) {
    return;
  }
  desktopStoreLink.onclick = function () { showMenu() };
  mobileStoreLink.onclick = function () { showMenu() };
}


/* Show submenus upon clicking the store links */
function showMenu() {
  if (desktopDropDown == null || mobileDropDown == null) {
    return;
  }
  if (!isSubMenuExpanded) {
    desktopDropDown.classList.remove('hidden');
    mobileDropDown.classList.remove('hidden');
    isSubMenuExpanded = true
  } else {
    desktopDropDown.classList.add('hidden');
    mobileDropDown.classList.add('hidden');
    isSubMenuExpanded = false;
  }
}

/* Set up image rollovers for all images. Assign the different image to each image's hover trigger event */
function onImageHover() {
  // Get all images on current page
  var imageList = document.getElementsByTagName('img');
  if (imageList == null || imageList.length == 0) {
    return;
  }

  // Now assign different image to each image on mouseover and original image back on mouse out
  for (i = 0; i < imageList.length; i++) {
    var currentImage = imageList.item(i);
    // Get original image
    originalImages[currentImage.getAttribute('alt')] = currentImage.getAttribute('src');
    
    currentImage.onmouseover = function (item) {
      item.target.setAttribute('src', 'images/logo.jpeg');
    };
    currentImage.onmouseout = function (item) {
      var temporaryImage = item.target;
      temporaryImage.setAttribute('src', originalImages[temporaryImage.getAttribute('alt')]);
    }
  }
}


/* Disable submit button if form is not valid */
function setUpFormValidation() {
  // Get input elements
  var inputs = document.getElementsByTagName('input');
  if (inputs == null) {
    return;
  }
  var validationInputs = []

  for (var i = 0; i < inputs.length; i++) {
    var inputType = inputs[i].getAttribute('type');
    if (inputType != null && (inputType == 'text' || inputType == 'email')) {
      validationInputs.push(inputs[i]);
    }
  }
  var validationCounts = 0;
  for (var i = 0; i < validationInputs.length; i++) {
    if (validationInputs[i].value != "" && validationInputs[i].checkValidity()) {
        validationCounts += 1;
    }
  }
  if (validationCounts != validationInputs.length && submitButton != null) {
      submitButton.disabled = true;
      submitButton.style.backgroundColor = "lightgrey";
  }
}


/* Called by the input element keypress to enable or disable the submit button */
function validateForm(event) {
  if (submitButton == null) {
    return;
  }
  
  if (event != null) {
    if (!event.target.checkValidity() || event.target.text == "") {
      submitButton.disabled = true;
      submitButton.style.backgroundColor = "lightgrey";
    } else {
      submitButton.disabled = false;
      submitButton.style.backgroundColor = "#288b0f";
    }
  }
  setUpFormValidation();
}

/* ========================================================

               JQUERY FUNCTIONS

===========================================================*/

/* global variables */
var isExpanded = false;

/* Load main page and setup clicks */

$(document).ready(function() {
  loadPage("main.html");
  setUpClicks();
});

/* set up button clicks to load page in same view */
function setUpClicks() {
  $('#btn-logo').on('click', function(e) {
    e.preventDefault();
    loadPage("main.html");
    isExpanded = false;
  });
  $('#btn-logo-mobile').on('click', function(e) {
    e.preventDefault();
    loadPage("main.html");
    isExpanded = false;
  });
  $('#btn-home').on('click', function(e) {
    e.preventDefault();
    loadPage("main.html");
    isExpanded = false;
  });
  $('#btn-home-mobile').on('click', function(e) {
    e.preventDefault();
    loadPage("main.html");
  });
  $('#btn-products').on('click', function(e) {
    e.preventDefault();
    loadPage("products.html");
  });
  $('#btn-products-mobile').on('click', function(e) {
    e.preventDefault();
    loadPage("products.html");
  });
  $('#btn-strains').on('click', function(e) {
    e.preventDefault();
    loadPage("strains.html");
  });
  $('#btn-strains-mobile').on('click', function(e) {
    e.preventDefault();
    loadPage("strains.html");
  });
  $('#btn-suppliers').on('click', function(e) {
    e.preventDefault();
    loadPage("suppliers.html");
  });
  $('#btn-suppliers-mobile').on('click', function(e) {
    e.preventDefault();
    loadPage("suppliers.html");
  });
  $('#btn-aboutus').on('click', function(e) {
    e.preventDefault();
    loadPage("aboutus.html");
  });
  $('#btn-aboutus-mobile').on('click', function(e) {
    e.preventDefault();
    loadPage("aboutus.html");
  });
  $('#btn-contactus').on('click', function(e) {
    e.preventDefault();
    loadPage("contactus.html");
  });
  $('#btn-contactus-mobile').on('click', function(e) {
    e.preventDefault();
    loadPage("contactus.html");
  });
  $('#btn-search').on('click', function(e) {
    e.preventDefault();
    loadPage("search.html");
  });
  $('#btn-cart').on('click', function(e) {
    e.preventDefault();
    loadPage("cart.html");
  });
  $('#btn-reviews').on('click', function(e) {
    e.preventDefault();
    loadPage("reviews.html");
  });
  $('#btn-reviews-mobile').on('click', function(e) {
    e.preventDefault();
    loadPage("reviews.html");
  });
}

/* ajax function call */
function loadPage(url) {
  $.ajax({
    url: url,
    success: function(result) {
      $('#main-content').html(result);
    }
  });
}

/* shop now button click handler */
function shopClicked(e) {
  e.preventDefault();
  loadPage("products.html");
}

/* set up expand form */
function expandOrCollapse(e) {
  e.preventDefault();
  if (!isExpanded) {
    $('#control-container').css("display", "block");
    $('#expand-button').text("-");
  } else {
    $('#control-container').css("display", "none");
    $('#expand-button').text("+");
  }
  isExpanded = !isExpanded;
}
